
package com.proyectoFinal.portfolio.security.enums;

public enum RolNombre {
    ROLE_ADMIN, ROLE_USER
}
